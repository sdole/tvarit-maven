from __future__ import print_function

import json
import boto3

print('Loading function')


def deployNewWar(event, context):
    print(event)
    print("Starting...")
    cfn = boto3.client('cloudformation')
    stacksToDelete = []
    allStacksDict = cfn.describe_stacks()
    for eachStack in allStacksDict:
        for eachTag in eachStack["Tags"]:
            if eachTag["Key"]=="tvarit:newInstanceStack":
                stacksToDelete.append(eachStack["StackId"])

    print(stacksToDelete)

    
